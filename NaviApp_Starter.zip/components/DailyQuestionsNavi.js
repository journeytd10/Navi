export const dailyQuestions = [
  'What do you value most in a friendship?',
  'What’s been on your heart and mind recently?',
  'What motivates you to get out of bed every day?'
];